#include "bintree.c"

// cd "/Users/onatalia86/Documents/ED1/Lista3.1/Exercicio1/" && gcc -lstdc++ bintreeMain.c -o bintreeMain && "/Users/onatalia86/Documents/ED1/Lista3.1/Exercicio1/"bintreeMain

int main(){

    return 0;
}
