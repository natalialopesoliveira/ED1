#include "matriz.c"

// cd ~/Documents/ED1/trab1 && gcc mainMatriz.c -o mainMatriz && ./mainMatriz
int main(){
    Celula *matriz,*mat;

	matriz = LeMatriz();


	imprimeMatriz(matriz);
	apagaMatriz(&matriz);
	return 0;
}
